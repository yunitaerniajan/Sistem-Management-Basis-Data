<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "monitoringtomat";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}

$nama_tomat         = "";
$suhu_tomat         = "";
$kadar_gas          = "";
$error              = "";
$sukses             = "";

if (isset($_GET['op'])) {
    $op = $_GET['op'];
} else {
    $op = "";
}

if ($op == 'edit') {
    $id_tomat           = $_GET['id_tomat'];
    $sql1               = "select * from monitoring where id_tomat = '$id_tomat'";
    $q1                 = mysqli_query($koneksi, $sql1);
    $r1                 = mysqli_fetch_array($q1);
    $nama_tomat         = $r1['nama_tomat'];
    $suhu_tomat         = $r1['suhu_tomat'];
    $kadar_gas          = $r1['kadar_gas'];

    if ($nama_tomat == '') {
        $error = "DATA TIDAK TERSEDIA";
    }
}

if (isset($_POST['simpan'])) { 
    $nama_tomat             = $_POST['nama_tomat'];
    $suhu_tomat             = $_POST['suhu_tomat'];
    $kadar_gas              = $_POST['kadar_gas'];

    if ($nama_tomat && $suhu_tomat && $kadar_gas) {
        if ($op == 'edit') { 
            $sql1       = "update monitoring set nama_tomat = '$nama_tomat',suhu_tomat='$suhu_tomat',kadar_gas = '$kadar_gas' where id_tomat = '$id_tomat'";
            $q1         = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses = "DATA SUKSES DIUPDATE";
            } else {
                $error  = "DATA GAGAL DIUPDATE";
            }
        } else {
            $sql1   = "insert into monitoring(nama_tomat,suhu_tomat,kadar_gas) values ('$nama_tomat','$suhu_tomat','$kadar_gas')";
            $q1     = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses     = "DATA BERHASIL DIINPUT";
            } else {
                $error      = "DATA GAGAL DIINPUT";
            }
        }
    } else {
        $error = "MOHON LENGKAPI DATA";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA MONITORING TOMAT SAYUR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            color: #ffffff; 
            background-image: url('tomato.jpg'); 
            background-size: cover; 
        }
        .container {
            margin-top: 40px;
        }
        .card {
            background-color: #1F592D; 
        }
        .card-header {
            background-color: #EAA600;
            color: white;
        }
        .btn-primary {
            background-color: #EAA600;
            border: none;
        }
        .btn-primary:hover {
            background-color: #F4C95F;
        }
        .card-body,
        .card-header,
        .form-label {
            color: #ffffff; 
        }
        .btn-primary {
            color: #ffffff;
        }
        .btn-container {
            display: flex;
            justify-content: space-between;
        }
        /* Tombol Kembali ke Indeks */
        .btn-kembali {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none; /* Menghilangkan garis bawah pada tautan */
        }
        .btn-kembali:hover {
            background-color: #0056b3;
        }
        .mb-0{
            text-align: center;
            font-size: 60px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card mt-4">
        <div class="card-header">
            <h3 class="mb-0">ISI DATA TOMAT</h3>
        </div>
        <div class="card-body">
            <?php
            if ($error) {
            ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error ?>
                </div>
            <?php
                header("refresh:5;url=form_data_monitoring.php"); //5 : detik
            }
            ?>
            <?php
            if ($sukses) {
            ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $sukses ?>
                </div>
            <?php
                header("refresh:5;url=form_data_monitoring.php");
            }
            ?>
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="nama_tomat" class="form-label">NAMA TOMAT</label>
                    <input type="text" class="form-control" id="nama_tomat" name="nama_tomat" value="<?php echo $nama_tomat ?>" required>
                </div>
                <div class="mb-3">
                    <label for="suhu_tomat" class="form-label">SUHU TOMAT</label>
                    <input type="text" class="form-control" id="suhu_tomat" name="suhu_tomat" value="<?php echo $suhu_tomat ?>" required>
                </div>
                <div class="mb-3">
                    <label for="kadar_gas" class="form-label">KADAR GAS</label>
                    <input type="text" class="form-control" id="kadar_gas" name="kadar_gas" value="<?php echo $kadar_gas ?>">
                </div>
                <div class="btn-container">
                    <a href="index.php" class="btn btn-kembali">Kembali ke list data</a>
                    <button type="submit" name="simpan" class="btn btn-primary">Submit Data</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
