<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "monitoringtomat";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { 
    die("tidak terkoneksi");
}

$nama_tomat         = "";
$suhu_tomat         = "";
$kadar_gas          = "";
$error              = "";
$sukses             = "";

if (isset($_GET['op'])) {
    $op = $_GET['op'];
} else {
    $op = "";
}
if ($op == 'delete') {
    $id_tomat         = $_GET['id_tomat'];
    $sql1       = "delete from monitoring where id_tomat = '$id_tomat'";
    $q1         = mysqli_query($koneksi, $sql1);
    if ($q1) {
        $sukses = "DATA SUKSES DIHAPUS";
    } else {
        $error  = "DATA GAGAL DIHAPUS";
    }
}
if ($op == 'edit') {
    $id_tomat           = $_GET['id_tomat'];
    $sql1               = "select * from monitoring where id_tomat = '$id_tomat'";
    $q1                 = mysqli_query($koneksi, $sql1);
    $r1                 = mysqli_fetch_array($q1);
    $nama_tomat         = $r1['nama_tomat'];
    $suhu_tomat         = $r1['suhu_tomat'];
    $kadar_gas          = $r1['kadar_gas'];

    if ($nama_tomat == '') {
        $error = "DATA TIDAK TERSEDIA";
    }
}
if (isset($_POST['simpan'])) { 
    $nama_tomat             = $_POST['nama_tomat'];
    $suhu_tomat             = $_POST['suhu_tomat'];
    $kadar_gas              = $_POST['kadar_gas'];

    if ($nama_tomat && $suhu_tomat && $kadar_gas) {
        if ($op == 'edit') { 
            $sql1       = "update monitoring set nama_tomat = '$nama_tomat',suhu_tomat='$suhu_tomat',kadar_gas = '$kadar_gas' where id_tomat = '$id_tomat'";
            $q1         = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses = "DATA SUKSES DIUPDATE";
            } else {
                $error  = "DATA GAGAL DIUPDATE";
            }
        } else { 
            $sql1   = "insert into monitoring(nama_tomat,suhu_tomat,kadar_gas) values ('$nama_tomat','$suhu_tomat','$kadar_gas')";
            $q1     = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses     = "DATA BERHASIL DIINPUT";
            } else {
                $error      = "DATA GAGAL DIINPUT";
            }
        }
    } else {
        $error = "MOHON LENGKAPI DATA";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA MONITORING TOMAT SAYUR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: #f0f0f0; /* Warna latar belakang */
            color: #333; /* Warna teks */
            background-image: url('tomato.jpg'); /* Tambahkan gambar ornamen di latar belakang */
            background-size: cover; /* Menyesuaikan ukuran latar belakang */
        }
        .container {
            margin-top: 20px;
        }
        .card {
            background-color: #ffffff; /* Warna latar belakang card */
            border: 1px solid #ddd; /* Warna border card */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Efek bayangan card */
        }
        .card-header {
            background-color: #28a745;
            color: white;
        }
        .btn-primary {
            background-color: #28a745;
            border: none;
        }
        .btn-primary:hover {
            background-color: #218838;
        }
        .table {
            background-color: #ffffff; /* Warna latar belakang tabel */
        }
        .table th, .table td {
            border-color: #ddd; /* Warna border tabel */
        }
        /* Warna teks untuk elemen di dalam card */
        .card-body,
        .card-header,
        .form-label,
        .table.table-striped tbody tr td {
            color: #E8836D; /* Warna teks */
        }
        /* Warna teks tombol di dalam card */
        .btn-primary {
            color: #ffffff;
        }
        /* Tombol Logout */
        .logout-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #dc3545;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        /* Tombol Menuju Form Data Monitoring */
        .btn-menuju-form {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none; /* Menghilangkan garis bawah pada tautan */
        }
        .btn-menuju-form:hover {
            background-color: #2A733B;
        }
        /* Teks Selamat Datang yang Ditengahkan */
        .teks-welcome {
            text-align: center;
            font-size: 24px;
            margin-top: 30px;
            color:#ffffff;
        }
        /* Teks Data Monitoring yang Ditengahkan */
        .teks-data-monitoring {
            text-align: center;
            font-size: 24px;
            margin-top: 20px;
            color:#ffffff;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Tombol Logout -->
        <a href="logout.php" class="logout-btn">LOGOUT</a>
    </div>

    <!-- Teks Selamat Datang Ditengahkan -->
    <div class="container mt-4 teks-welcome">
        <h2>WELCOME!, <?php echo $_SESSION['username']; ?>!</h2>
    </div>

    <!-- Teks Data Monitoring Ditengahkan -->
    <div class="container mt-4 teks-data-monitoring">
        <h3>Data Monitoring Tomat</h3>
    </div>

    <div class="container mt-4">
        <!-- Untuk mengeluarkan data -->
        <div class="card">
            <div class="card-body">
                <a href="form_data_monitoring.php" class="btn btn-menuju-form">ISI DATA TOMAT</a>

                <table class="table table-striped mt-4">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">NAMA TOMAT</th>
                            <th scope="col">SUHU TOMAT</th>
                            <th scope="col">KADAR GAS</th>
                            <th scope="col">TINDAKAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql2   = "select * from monitoring order by id_tomat desc";
                        $q2     = mysqli_query($koneksi, $sql2);
                        $urut   = 1;
                        while ($r2 = mysqli_fetch_array($q2)) {
                            $id_tomat           = $r2['id_tomat'];
                            $nama_tomat         = $r2['nama_tomat'];
                            $suhu_tomat         = $r2['suhu_tomat'];
                            $kadar_gas          = $r2['kadar_gas'];

                        ?>
                            <tr>
                                <th scope="row"><?php echo $urut++ ?></th>
                                <td><?php echo $nama_tomat ?></td>
                                <td><?php echo $suhu_tomat ?></td>
                                <td><?php echo $kadar_gas ?></td>
                                <td>
                                    <a href="index.php?op=edit&id_tomat=<?php echo $id_tomat ?>"><button type="button" class="btn btn-warning">EDIT</button></a>
                                    <a href="index.php?op=delete&id_tomat=<?php echo $id_tomat ?>" onclick="return confirm('APAKAH ANDA YAKIN?')"><button type="button" class="btn btn-danger">HAPUS</button></a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
