<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "monitoringtomatnew";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA MONITORING TOMAT SAYUR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            color: #ffffff;
            background-image: url('tomato.jpg');
            background-size: cover;
        }
        .container {
            margin-top: 40px;
        }
        .card {
            background-color: #1F592D;
            color:#ffffff;
        }
        .card-header {
            background-color: #EAA600;
            color: white;
        }
        .btn-primary {
            background-color: #EAA600;
            border: none;
        }
        .btn-primary:hover {
            background-color: #F4C95F;
        }
        .card-body{
            color:#ffffff;
        }
        
       /* Gaya tambahan untuk teks dalam tabel */
        .table,
        .table th,
        .table td {
        color: #ffffff; /* Warna teks tabel (putih) */
        }

        /* Gaya tambahan untuk header tabel */
        .table thead th {
        background-color: #1F592D; /* Warna latar belakang header tabel */
        color: #ffffff; /* Warna teks header tabel (putih) */
        }

        /* Gaya tambahan untuk baris ganjil dalam tabel */
        .table tbody tr:nth-child(odd) {
        background-color: #1F592D; /* Warna latar belakang baris ganjil (darker green) */
        }

        .form-label {
            color: #ffffff;
        }
        .btn-primary {
            color: #ffffff;
        }
        .btn-container {
            display: flex;
            justify-content: space-between;
        }
        /* Tombol Kembali ke Indeks */
        
        .mb-0 {
            text-align: center;
            font-size: 60px;
        }
        /* Gaya tambahan untuk teks selamat datang dan data monitoring */
        .teks-welcome, .teks-data-monitoring {
            text-align: center;
            color: #ffffff;
            font-size: 24px;
            margin-top: 20px;
        }
        /* Gaya untuk tombol menuju form */
        .btn-menuju-form {
            background-color: #EAA600;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
        }
        .btn-menuju-form:hover {
            background-color: #F4C95F;
        }

        

        /* CSS untuk tombol LOGOUT */
        .logout-btn {
        display: inline-block;
        padding: 10px 50px; /* Atur padding sesuai keinginan Anda */
        font-size: 16px; /* Ukuran font teks */
        background-color: #FF0000; /* Warna latar belakang (merah) */
        color: #FFFFFF; /* Warna teks (putih) */
        border: none;
        border-radius: 5px;
        cursor: pointer;
        text-decoration: none;
        transition: background-color 0.3s; /* Transisi warna latar belakang */
        margin-right: 10px; /* Atur margin sesuai keinginan Anda */
        margin-bottom:20px;
        }

/* Efek hover saat kursor berada di atas tombol */
        .logout-btn:hover {
        background-color: #FF3333; /* Warna latar belakang berubah saat hover (merah muda) */
        }

    </style>
</head>
<body>


    <!-- Teks Selamat Datang Ditengahkan -->
    <div class="container mt-4 teks-welcome">
        <h2>WELCOME, <?php echo $_SESSION['username']; ?>!</h2>
    </div>

    <!-- Teks Data Monitoring Ditengahkan -->
    <div class="container mt-4 teks-data-monitoring">
        <h3>Data Monitoring Tomat</h3>
    </div>

    <div class="container mt-4">
        <!-- Untuk mengeluarkan data -->
        <div class="card">
            <div class="card-body">
                <a href="form_data_monitoring.php" class="btn btn-menuju-form">ISI DATA TOMAT</a>

                <table class="table table-striped mt-4">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID TOMAT</th>
                            <th scope="col">NAMA TOMAT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sqltomat = "SELECT * FROM tomat";
                        $resulttomat = mysqli_query($koneksi, $sqltomat);
                        $urut = 1;
                        while ($rowtomat = mysqli_fetch_array($resulttomat)) {
                            $id_tomat = htmlspecialchars($rowtomat['id_tomat']);
                            $nama_tomat = htmlspecialchars($rowtomat['nama_tomat']);
                        ?>
                            <tr>
                                <th scope="row"><?php echo $urut++ ?></th>
                                <td><?php echo $id_tomat ?></td>
                                <td><?php echo $nama_tomat ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                DATA SUHU TOMAT
            </div>
            <div class="card-body">
                <table class="table table-striped mt-4">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID TOMAT</th>
                            <th scope="col">SUHU TOMAT</th>
                            <th scope="col">TANGGAL TOMAT</th>
                            <th scope="col">WAKTU TOMAT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sqlsuhu = "SELECT * FROM suhu";
                        $resultsuhu = mysqli_query($koneksi, $sqlsuhu);
                        $urut = 1;
                        while ($rowsuhu = mysqli_fetch_array($resultsuhu)) {
                            $id_tomatsuhu = htmlspecialchars($rowsuhu['id_tomatsuhu']);
                            $suhu_tomat = htmlspecialchars($rowsuhu['suhu_tomat']);
                            $tanggal_tomatsuhu = htmlspecialchars($rowsuhu['tanggal_tomatsuhu']);
                            $waktu_tomatsuhu = htmlspecialchars($rowsuhu['waktu_tomatsuhu']);
                        ?>
                            <tr>
                                <th scope="row"><?php echo $urut++ ?></th>
                                <td><?php echo $id_tomatsuhu ?></td>
                                <td><?php echo $suhu_tomat ?></td>
                                <td><?php echo $tanggal_tomatsuhu ?></td>
                                <td><?php echo $waktu_tomatsuhu ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                DATA KADAR GAS
            </div>
            <div class="card-body">
                <table class="table table-striped mt-4">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID TOMAT</th>
                            <th scope="col">KADAR GAS</th>
                            <th scope="col">TANGGAL TOMAT</th>
                            <th scope="col">WAKTU TOMAT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sqlgas = "SELECT * FROM gas";
                        $resultgas = mysqli_query($koneksi, $sqlgas);
                        $urut = 1;
                        while ($rowgas = mysqli_fetch_array($resultgas)) {
                            $id_tomatgas = htmlspecialchars($rowgas['id_tomatgas']);
                            $kadar_gas = htmlspecialchars($rowgas['kadar_gas']);
                            $tanggal_gastomat = htmlspecialchars($rowgas['tanggal_tomatgas']);
                            $waktu_tomatgas = htmlspecialchars($rowgas['waktu_tomatgas']);
                        ?>
                            <tr>
                                <th scope="row"><?php echo $urut++ ?></th>
                                <td><?php echo $id_tomatgas ?></td>
                                <td><?php echo $kadar_gas ?></td>
                                <td><?php echo $tanggal_gastomat ?></td>
                                <td><?php echo $waktu_tomatgas ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- Tombol Logout -->
        <a href="logout.php" class="logout-btn">LOGOUT</a>
    </div>
</body>
</html>
