<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Monitor Buah</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #FFFFFF; /* Warna teks */
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-image: url('tomatologin.jpg'); /* Gambar latar belakang */
            background-size: cover;
            background-repeat: no-repeat;
        }

        .container {
            width: 80%;
            max-width: 500px;
            padding: 40px;
            background-color: #1F592D; /* Warna latar belakang container */
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.5); /* Efek bayangan */
            display: flex;
            align-items: center;
            justify-items: center;
            flex-direction: column;
        }

        h2 {
            text-align: center;
            color: #EAA600; /* Warna teks judul */
        }

        form {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-size: 20px;
            color: #FFFFFF; /* Warna teks label */
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.2); /* Warna latar belakang input */
            color: #EAA600; /* Warna teks input */
            font-size: 16px;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            background-color: rgba(255, 255, 255, 0.3); /* Warna latar belakang input saat fokus */
        }

        button {
            background-color: #EAA600; /* Warna latar belakang tombol */
            color: #FFFFFF; /* Warna teks tombol */
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            margin-bottom: 20px;
        }

        button:hover {
            background-color: #F4C95F; /* Warna latar belakang tombol saat hover */
        }

        .alert {
            background-color: #D32F2F; /* Warna latar belakang alert */
            color: #FFFFFF; /* Warna teks alert */
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }

        a {
            color: #ffffff; /* Warna teks tautan */
            text-decoration: none;
            display: block;
            text-align: center;
            font-weight: bold; /* Teks tebal */
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Registrasi</h2>
    <?php
    session_start();
    if (isset($_SESSION['username'])) {
        header('Location: login.php');
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "monitoringtomatnew";

        $koneksi = mysqli_connect($host, $user, $pass, $db);
        if (!$koneksi) {
            die("Koneksi gagal: " . mysqli_connect_error());
        }

        // Menggunakan prepared statement untuk menghindari SQL Injection
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        $stmt = mysqli_prepare($koneksi, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $username, $password);

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['username'] = $username;
            header('Location: login.php');
            exit();
        } else {
            $error = "GAGAL TERDAFTAR";
        }

        mysqli_stmt_close($stmt);
        mysqli_close($koneksi);
    }
    ?>

    <?php if (isset($error)) : ?>
        <div class="alert" role="alert">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <!-- Formulir registrasi -->
        <div class="mb-3">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Registrasi</button>
    </form>

    <a href="login.php">Login</a>
</div>
</body>
</html>
