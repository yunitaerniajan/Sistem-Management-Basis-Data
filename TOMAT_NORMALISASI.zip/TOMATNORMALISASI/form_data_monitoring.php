<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "monitoringtomatnew";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { 
    die("Tidak terkoneksi ke database");
}

$id_tomat = $nama_tomat = $errortomat = $suksestomat = "";
$id_tomatsuhu = $suhu_tomat = $tanggal_tomatsuhu = $waktu_tomatsuhu = $errorsuhu = $suksessuhu = "";
$id_tomatgas = $kadar_gas = $tanggal_tomatgas = $waktu_tomatgas = $errorgas = $suksesgas = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Form TOMAT
    if (isset($_POST['simpantomat'])) {
        $id_tomat = $_POST['id_tomat'];
        $nama_tomat = $_POST['nama_tomat'];

        if ($id_tomat && $nama_tomat) {
            $sqltomat = "INSERT INTO tomat (id_tomat, nama_tomat) VALUES (?, ?)";
            $stmt = mysqli_prepare($koneksi, $sqltomat);
            mysqli_stmt_bind_param($stmt, "ss", $id_tomat, $nama_tomat);

            if (mysqli_stmt_execute($stmt)) {
                $suksestomat = "DATA BERHASIL DIINPUT";
                $id_tomat = $nama_tomat = "";
            } else {
                $errortomat = "DATA GAGAL DIINPUT";
            }

            mysqli_stmt_close($stmt);
        } else {
            $errortomat = "LENGKAPI DATA";
        }
    }
    // Form Suhu
    if (isset($_POST['simpansuhu'])) {
        $id_tomatsuhu = $_POST['id_tomatsuhu'];
        $suhu_tomat = $_POST['suhu_tomat'];
        $tanggal_tomatsuhu = $_POST['tanggal_tomatsuhu'];
        $waktu_tomatsuhu = $_POST['waktu_tomatsuhu'];
    
        if ($id_tomatsuhu && $suhu_tomat && $tanggal_tomatsuhu && $waktu_tomatsuhu) {
            $sqlsuhu = "INSERT INTO suhu (id_tomatsuhu, suhu_tomat, tanggal_tomatsuhu, waktu_tomatsuhu) VALUES (?,?, ?, ?)";
            $stmt = mysqli_prepare($koneksi, $sqlsuhu);
    
            // Periksa apakah mysqli_prepare berhasil
            if ($stmt) {
                // Mengikat parameter dengan benar
                mysqli_stmt_bind_param($stmt, "ssss", $id_tomatsuhu, $suhu_tomat, $tanggal_tomatsuhu, $waktu_tomatsuhu);
    
                if (mysqli_stmt_execute($stmt)) {
                    $suksessuhu = "DATA BERHASIL DIINPUT";
                    $id_tomatsuhu = $suhu_tomat = $tanggal_tomatsuhu = $waktu_tomatsuhu = "";
                } else {
                    $errorsuhu = "DATA GAGAL DIINPUT";
                }
    
                mysqli_stmt_close($stmt);
            } else {
                $errorsuhu = "GAGAL MENYIAPKAN PERNYATAAN";
            }
        } else {
            $errorsuhu = "LENGKAPI DATA";
        }
    }
    
    // Form GAS
    // Form GAS
// Form GAS
if (isset($_POST['simpangas'])) {
    $id_tomatgas = $_POST['id_tomatgas'];
    $kadar_gas = $_POST['kadar_gas'];
    $tanggal_tomatgas = $_POST['tanggal_tomatgas'];
    $waktu_tomatgas = $_POST['waktu_tomatgas'];

    if ($id_tomatgas && $kadar_gas && $tanggal_tomatgas && $waktu_tomatgas) {
        $sqlgas = "INSERT INTO gas (id_tomatgas, kadar_gas, tanggal_tomatgas, waktu_tomatgas) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $sqlgas);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssss", $id_tomatgas, $kadar_gas, $tanggal_tomatgas, $waktu_tomatgas);

            if (mysqli_stmt_execute($stmt)) {
                // Setelah berhasil INSERT, ambil ID yang baru saja dibuat
                $newlyInsertedID = mysqli_insert_id($koneksi);
                $suksesgas = "DATA BERHASIL DIINPUT. ID: " . $newlyInsertedID;
                $id_tomatgas = $kadar_gas = $tanggal_tomatgas = $waktu_tomatgas = "";
            } else {
                $errorgas = "DATA GAGAL DIINPUT";
            }

            mysqli_stmt_close($stmt);
        } else {
            $errorgas = "GAGAL MENYIAPKAN PERNYATAAN";
        }
    } else {
        $errorgas = "LENGKAPI DATA";
    }
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA MONITORING TOMAT SAYUR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            color: #ffffff;
            background-image: url('tomato.jpg');
            background-size: cover;
        }
        .container {
            margin-top: 40px;
            justify conten
        }
        .card {
            background-color: #1F592D;
        }
        .card-header {
            background-color: #EAA600;
            color: white;
        }
        .btn-primary {
            background-color: #EAA600;
            border: none;
        }
        .btn-primary:hover {
            background-color: #F4C95F;
        }
        .card-body,
        .card-header,
        .form-label {
            color: #ffffff;
        }
        .btn-primary {
            color: #ffffff;
        }
        .btn-container {
            display: flex;
            justify-content: space-between;
        }
        /* Tombol Kembali ke Indeks */
        .btn-kembali {
        display: inline-block;
        padding: 10px 50px; /* Atur padding sesuai keinginan Anda */
        font-size: 16px; /* Ukuran font teks */
        background-color: #77B2F9; /* Warna latar belakang (merah) */
        color: #FFFFFF; /* Warna teks (putih) */
        border: none;
        border-radius: 5px;
        cursor: pointer;
        text-decoration: none;
        transition: background-color 0.3s; /* Transisi warna latar belakang */
        margin-right: 10px; /* Atur margin sesuai keinginan Anda */
        margin-bottom:20px;
        margin-top:10px;
        }

        .container input[type="text"] {
        width: 100%; 
        padding: 10px; 
        text-align: left; 
        border: 1px solid #ccc; 
        border-radius: 5px; 
        }
        .container input[type="date"] {
        width: 100%; 
        padding: 10px; 
        text-align: left; 
        border: 1px solid #ccc; 
        border-radius: 5px; 
        }
        .container input[type="time"] {
        width: 100%; 
        padding: 10px; 
        text-align: left; 
        border: 1px solid #ccc;
        border-radius: 5px; 
        }
        /* CSS untuk tombol submit form */
        button[type="submit"] {
        background-color: #1F592D; /* Warna latar belakang tombol */
        color: #ffffff; /* Warna teks pada tombol */
        padding: 10px 20px; /* Atur padding sesuai keinginan Anda */
        border: none; /* Hapus border tombol */
        border-radius: 5px; /* Atur radius sudut tombol */
        cursor: pointer; /* Ganti cursor saat diarahkan ke tombol */
        transition: background-color 0.3s; /* Transisi warna latar belakang saat tombol dihover */
        }

/* Efek hover saat kursor berada di atas tombol submit */
        button[type="submit"]:hover {
        background-color: #236D35; /* Warna latar belakang tombol saat dihover */
        }



/* Efek hover saat kursor berada di atas tombol */
        .btn-kembali:hover {
        background-color: #0056b3; /* Warna latar belakang berubah saat hover (biru lebih gelap) */
        }
        .mb-0 {
            text-align: center;
            font-size: 40px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card mt-4">
            <div class="card-header">
                <!-- Form Input Data TOMAT -->
                <h3 class="mb-0">ISI DATA TOMAT</h3>
                <?php if ($errortomat) : ?>
                    <div style="color: red;"><?php echo $errortomat; ?></div>
                <?php endif; ?>
                <?php if ($suksestomat) : ?>
                    <div style="color: green;"><?php echo $suksestomat; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <label for="id_tomat">ID TOMAT:</label>
                    <input type="text" id="id_tomat" name="id_tomat" value="<?php echo $id_tomat; ?>" required><br><br>

                    <label for="nama_tomat">NAMA TOMAT:</label>
                    <input type="text" id="nama_tomat" name="nama_tomat" value="<?php echo $nama_tomat; ?>" required><br><br>

                    <button type="submit" name="simpantomat">SUBMIT DATA TOMAT</button>
                </form>
            </div>
        </div>
        <div class="card mt-4">
            <div class="card-header">
                <!-- Form Input Data SUHU -->
                <h3 class="mb-0">ISI DATA SUHU TOMAT</h3>
                <?php if ($errorsuhu) : ?>
                    <div style="color: red;"><?php echo $errorsuhu; ?></div>
                <?php endif; ?>
                <?php if ($suksessuhu) : ?>
                    <div style="color: green;"><?php echo $suksessuhu; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <label for="id_tomatsuhu">ID TOMAT:</label>
                    <input type="text" id="id_tomatsuhu" name="id_tomatsuhu" value="<?php echo $id_tomatsuhu; ?>" required><br><br>

                    <label for="suhu_tomat">SUHU TOMAT:</label>
                    <input type="text" id="suhu_tomat" name="suhu_tomat" value="<?php echo $suhu_tomat; ?>" required><br><br>

                    <label for="tanggal_tomatsuhu">TANGGAL TOMAT:</label>
                    <input type="date" id="tanggal_tomatsuhu" name="tanggal_tomatsuhu" value="<?php echo $tanggal_tomatsuhu; ?>" required><br><br>

                    <label for="waktu_tomatsuhu">WAKTU TOMAT:</label>
                    <input type="time" id="waktu_tomatsuhu" name="waktu_tomatsuhu" value="<?php echo $waktu_tomatsuhu; ?>" required><br><br>

                    <button type="submit" name="simpansuhu">SUBMIT DATA SUHU TOMAT</button>
                </form>
            </div>
        </div>
        <div class="card mt-4">
            <div class="card-header">
                <!-- Form Input Data GAS -->
                <h3 class="mb-0">ISI DATA GAS TOMAT</h3>
                <?php if ($errorgas) : ?>
                    <div style="color: red;"><?php echo $errorgas; ?></div>
                <?php endif; ?>
                <?php if ($suksesgas) : ?>
                    <div style="color: green;"><?php echo $suksesgas; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <label for="id_tomatgas">ID TOMAT:</label>
                    <input type="text" id="id_tomatgas" name="id_tomatgas" value="<?php echo $id_tomatgas; ?>" required><br><br>

                    <label for="kadar_gas">KADAR GAS:</label>
                    <input type="text" id="kadar_gas" name="kadar_gas" value="<?php echo $kadar_gas; ?>" required><br><br>

                    <label for="tanggal_tomatgas">TANGGAL TOMAT:</label>
                    <input type="date" id="tanggal_tomatgas" name="tanggal_tomatgas" value="<?php echo $tanggal_tomatgas; ?>" required><br><br>

                    <label for="waktu_tomatgas">WAKTU TOMAT:</label>
                    <input type="time" id="waktu_tomatgas" name="waktu_tomatgas" value="<?php echo $waktu_tomatgas; ?>" required><br><br>

                    <button type="submit" name="simpangas">SUBMIT DATA GAS TOMAT</button>
                </form>
            </div>
        </div>
        <a href="index.php" class="btn-kembali" >Kembali ke Indeks</a>
    </div>
</body>
</html>
